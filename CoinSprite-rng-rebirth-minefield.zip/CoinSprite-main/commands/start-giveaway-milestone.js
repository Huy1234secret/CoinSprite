const {
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  MessageFlags,
} = require('discord.js');
const { randomUUID } = require('crypto');
const { loadState, saveState } = require('../src/milestoneStore');

// Refresh every 5 minutes to avoid aggressive member chunk requests/rate limits.
const REFRESH_INTERVAL_MS = 5 * 60 * 1000;
const COMPONENTS_V2_FLAG = MessageFlags.IsComponentsV2 ?? 32768;
const EPHEMERAL_FLAG = MessageFlags.Ephemeral ?? 64;
const PING_ROLE_ID = '1493901068688429207';

let clientRef = null;
let refreshTimer = null;
const memberFetchCooldownUntil = new Map();

function percent(current, target) {
  if (!target || target <= 0) {
    return 0;
  }
  return Math.max(0, Math.min(100, Math.floor((current / target) * 100)));
}

function progressBar(current, target, size = 18) {
  const pct = percent(current, target);
  const filled = Math.round((pct / 100) * size);
  return `## ${'█'.repeat(filled)}${'░'.repeat(Math.max(0, size - filled))} ${pct}%`;
}

function normalizeRewards(text) {
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 20);
}

function buildMilestonePayload(state, userCount, reached = false) {
  const pct = percent(userCount, state.milestoneUsers);
  const nextRefresh = Math.floor((Date.now() + REFRESH_INTERVAL_MS) / 1000);
  const rewardLines = state.rewardLines.length
    ? state.rewardLines.map((line) => `• ${line}`).join('\n')
    : '• Surprise reward';
  const winnerLine = `(Winner: ${state.winnerCount ?? 1})`;

  const progressText = progressBar(userCount, state.milestoneUsers);
  const summary = `${userCount} / ${state.milestoneUsers} (${pct}%)`;

  const baseTitle = reached
    ? '## 🎯 MILESTONE REACHED! 🏆\nA giveaway will begin soon!'
    : '## 🎯 MILESTONE\nA giveaway will begin when we reached the milestone!';

  const giveawaySection = reached
    ? `🎁Giveaway prize:\n${rewardLines}\n${winnerLine}`
    : `🎁Giveaway prize:\n${rewardLines}\n${winnerLine}\n-# Refresh <t:${nextRefresh}:R>`;

  const cardComponents = [];

  if (reached) {
    cardComponents.push({
      type: 10,
      content: `<@&${PING_ROLE_ID}>`,
    });
    cardComponents.push({
      type: 14,
      divider: true,
      spacing: 1,
    });
  }

  cardComponents.push(
    {
      type: 10,
      content: baseTitle,
    },
    {
      type: 14,
      divider: true,
      spacing: 1,
    },
    {
      type: 9,
      components: [
        {
          type: 10,
          content: progressText,
        },
      ],
      accessory: {
        type: 2,
        style: 2,
        custom_id: `milestone_status_${state.guildId}`,
        label: summary,
        disabled: true,
      },
    },
    {
      type: 14,
      divider: true,
      spacing: 1,
    },
    {
      type: 10,
      content: giveawaySection,
    },
  );

  return {
    flags: COMPONENTS_V2_FLAG,
    allowed_mentions: reached ? { parse: ['roles'], roles: [PING_ROLE_ID] } : undefined,
    components: [
      {
        type: 17,
        accent_color: 0x00ff00,
        components: cardComponents,
      },
    ],
  };
}

function getRetryAfterMs(error) {
  const retryAfterSeconds = Number(error?.data?.retry_after);
  if (!Number.isFinite(retryAfterSeconds) || retryAfterSeconds <= 0) {
    return null;
  }
  return Math.ceil(retryAfterSeconds * 1000);
}

async function getHumanMemberCount(guild, fallbackCount = null) {
  const cooldownUntil = memberFetchCooldownUntil.get(guild.id) ?? 0;
  if (cooldownUntil > Date.now()) {
    return fallbackCount ?? guild.memberCount ?? 0;
  }

  try {
    const members = await guild.members.fetch();
    return members.filter((member) => !member.user.bot).size;
  } catch (error) {
    const retryAfterMs = getRetryAfterMs(error);
    if (retryAfterMs) {
      memberFetchCooldownUntil.set(guild.id, Date.now() + retryAfterMs);
      return fallbackCount ?? guild.memberCount ?? 0;
    }
    throw error;
  }
}

function upsertMilestoneState(nextState) {
  const state = loadState();
  const nextKey = nextState.id ?? nextState.messageId;
  const filtered = state.milestones.filter((m) => (m.id ?? m.messageId) !== nextKey);
  filtered.push(nextState);
  saveState({ milestones: filtered });
}

function removeMilestoneState(entry) {
  const state = loadState();
  const entryKey = entry.id ?? entry.messageId;
  const filtered = state.milestones.filter((m) => (m.id ?? m.messageId) !== entryKey);
  saveState({ milestones: filtered });
}

async function refreshMilestoneEntry(entry, preloadedHumanCount = null) {
  if (!clientRef) {
    return;
  }

  const guild = await clientRef.guilds.fetch(entry.guildId).catch(() => null);
  if (!guild) {
    return;
  }

  const channel = await guild.channels.fetch(entry.channelId).catch(() => null);
  if (!channel?.isTextBased()) {
    return;
  }

  const humanCount =
    preloadedHumanCount !== null && preloadedHumanCount !== undefined
      ? preloadedHumanCount
      : await getHumanMemberCount(guild, entry.lastKnownUsers);
  const reached = humanCount >= entry.milestoneUsers;

  if (!reached) {
    const payload = buildMilestonePayload(entry, humanCount, false);
    await channel.messages.edit(entry.messageId, payload).catch(() => null);
    upsertMilestoneState({ ...entry, lastKnownUsers: humanCount, reached: false, updatedAt: Date.now() });
    return;
  }

  if (!entry.reached) {
    await channel.messages.delete(entry.messageId).catch(() => null);
    const reachedPayload = buildMilestonePayload(entry, humanCount, true);
    await channel.send(reachedPayload);
    removeMilestoneState(entry);
    return;
  }

  removeMilestoneState(entry);
}

async function refreshAllMilestones() {
  const state = loadState();
  const guildCountCache = new Map();
  for (const entry of state.milestones) {
    try {
      if (!guildCountCache.has(entry.guildId)) {
        const guild = await clientRef?.guilds.fetch(entry.guildId).catch(() => null);
        const humanCount = guild ? await getHumanMemberCount(guild, entry.lastKnownUsers).catch(() => null) : null;
        guildCountCache.set(entry.guildId, humanCount);
      }

      await refreshMilestoneEntry(entry, guildCountCache.get(entry.guildId));
    } catch (error) {
      console.error(`Failed to refresh milestone for guild ${entry.guildId}:`, error);
    }
  }
}

function startRefreshWorker() {
  if (refreshTimer) {
    clearInterval(refreshTimer);
  }
  refreshTimer = setInterval(() => {
    void refreshAllMilestones();
  }, REFRESH_INTERVAL_MS);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('start-giveaway-milestone')
    .setDescription('Start a milestone-tracked giveaway panel.'),

  async init(client) {
    clientRef = client;
    startRefreshWorker();
    await refreshAllMilestones();
  },

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('milestone_modal_create')
      .setTitle('Start Giveaway Milestone');

    const rewardInput = new TextInputBuilder()
      .setCustomId('milestone_reward')
      .setLabel('Giveaway Reward')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setPlaceholder('List giveaway rewards (one per line).')
      .setMaxLength(1800);

    const winnerInput = new TextInputBuilder()
      .setCustomId('milestone_winner')
      .setLabel('Winner (number only)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('Example: 3')
      .setMaxLength(5);

    const milestoneInput = new TextInputBuilder()
      .setCustomId('milestone_users')
      .setLabel('User milestone (number only)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('Example: 500')
      .setMaxLength(7);

    modal.addComponents(
      new ActionRowBuilder().addComponents(rewardInput),
      new ActionRowBuilder().addComponents(winnerInput),
      new ActionRowBuilder().addComponents(milestoneInput),
    );

    await interaction.showModal(modal);
  },

  async handleInteraction(interaction) {
    if (!interaction.isModalSubmit() || interaction.customId !== 'milestone_modal_create') {
      return false;
    }

    const rewardText = interaction.fields.getTextInputValue('milestone_reward').trim();
    const winnerRaw = interaction.fields.getTextInputValue('milestone_winner').trim();
    const milestoneRaw = interaction.fields.getTextInputValue('milestone_users').trim();

    if (!/^\d+$/.test(winnerRaw) || !/^\d+$/.test(milestoneRaw)) {
      await interaction.reply({
        content: 'Winner and User milestone must be numbers only.',
        flags: EPHEMERAL_FLAG,
      });
      return true;
    }

    const winnerCount = Number(winnerRaw);
    const milestoneUsers = Number(milestoneRaw);
    if (winnerCount <= 0 || milestoneUsers <= 0) {
      await interaction.reply({
        content: 'Winner and User milestone must be greater than 0.',
        flags: EPHEMERAL_FLAG,
      });
      return true;
    }

    await interaction.deferReply({ flags: EPHEMERAL_FLAG });

    const humanCount = await getHumanMemberCount(interaction.guild);
    const rewardLines = normalizeRewards(rewardText);

    const stateEntry = {
      id: randomUUID(),
      guildId: interaction.guildId,
      channelId: interaction.channelId,
      messageId: '',
      rewardText,
      rewardLines,
      winnerCount,
      milestoneUsers,
      createdBy: interaction.user.id,
      reached: false,
      lastKnownUsers: humanCount,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    const panel = await interaction.channel.send(buildMilestonePayload(stateEntry, humanCount, false));

    stateEntry.messageId = panel.id;
    upsertMilestoneState(stateEntry);

    await interaction.editReply({
      content: `Milestone giveaway panel started.\nTarget: **${milestoneUsers} users**\nWinners: **${winnerCount}**`,
    });

    return true;
  },
};
