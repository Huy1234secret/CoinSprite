# Rng Game

RNG slash commands:
- `/roll` — roll an alphabet and earn PRcoin.
- `/balance` — show PRcoin and Rebirth Coin balances.
- `/upgrades` — switch between Coin Upgrades and Rebirth Upgrades.
- `/rebirth` — reset PRcoin and coin upgrades for permanent rebirth perks.
- `/minefield` — unlocked by the Minefield Fortune rebirth upgrade.

## Rebirth summary

Rebirth keeps the requested perks:
- Rebirth 1: x2 coin earn, x1.05 luck, +1 Rebirth Coin, unlock Rebirth Upgrades.
- Rebirth 2: x4 coin earn, x1.10 luck, +1 Rebirth Coin.
- Rebirth 3: x8 coin earn, x1.15 luck, +1 Rebirth Coin.
- Rebirth 4: x16 coin earn, x1.20 luck, +1 Rebirth Coin.
- Rebirth 5: x32 coin earn, x1.25 luck, +1 Rebirth Coin, unlock Challenges.

Upon rebirth, PRcoin, coin upgrades, and stored roll charge are reset. Discovered alphabets and Rebirth Upgrades are kept.
